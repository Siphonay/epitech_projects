/*
** calc.c for fakeProj in /home/sam
**
** Made by Alexis Viguié
** Login   <sam@epitech.net>
**
** Started on  Mon Jun 27 15:41:31 2016 Alexis Viguié
** Last update Mon Jun 27 15:41:33 2016 Alexis Viguié
*/

int	op_add(int nb1, int nb2)
{
  return (nb1 + nb2);
}

int	op_sub(int nb1, int nb2)
{
  return (nb1 - nb2);
}

int	op_mul(int nb1, int nb2)
{
  return (nb1 * nb2);
}

int	op_div(int nb1, int nb2)
{
  return (nb1 / nb2);
}

int	op_mod(int nb1, int nb2)
{
  return (nb1 % nb2);
}
