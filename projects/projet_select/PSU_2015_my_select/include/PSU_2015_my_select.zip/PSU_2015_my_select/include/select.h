/*
** select.h for my select in /home/sam/projet_select/PSU_2015_my_select/include
**
** Made by Alexis Viguié
** Login   <sam@epitech.net>
**
** Started on  Sun Dec 13 19:53:18 2015 Alexis Viguié
** Last update Sun Dec 13 22:12:44 2015 Alexis Viguié
*/

#ifndef SELECT_H_
# define SELECT_H_
void	print_select_exit(char **args, int *index, int ac);
void	arg_err(char **av);
void	malloc_err();
void	wsize_err();
#endif /* SELECT_H_ */
