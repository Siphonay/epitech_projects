/*
** main.c for my select in /home/sam
**
** Made by Alexis Viguié
** Login   <sam@epitech.net>
**
** Started on  Fri Dec  4 14:58:09 2015 Alexis Viguié
** Last update Sun Dec 13 22:28:04 2015 Alexis Viguié
*/

#include <stdlib.h>
#include <ncurses.h>
#include "sam.h"
#include "select.h"

int	*build_index_table(int ac)
{
  int	*index_ret;
  int	counter;

  if ((index_ret = malloc(sizeof(int) * ac - 1)) == NULL)
    malloc_err();
  counter = 0;
  while (counter < (ac - 1))
    {
      index_ret[counter] = 0;
      counter++;
    }
  return (index_ret);
}

int	disp_select(int pos, int *index, char **elems, WINDOW *ncwin, int *wsize)
{
  int	counter;
  int	vpos;
  int	hpos;
  int	next_hpos;

  vpos = 0;
  hpos = 0;
  counter = 1;
  next_hpos = 0;
  while (elems[counter])
    {
      if ((vpos + 1) > wsize[0])
	vpos = 0;
      if ((vpos == 0) && (counter > 1))
	{
	  hpos = hpos + next_hpos + 8;
	  next_hpos = 0;
	}
      if (hpos > wsize[1])
	{
	  wsize_err();
	}
      if (index[counter] == 2)
	{
	  if (pos == counter)
	    {
	      if (!elems[pos + 1])
		pos = 0;
	      else
		pos++;
	    }
	}
      else
	{
	  if ((sam_strlen(elems[counter]) + hpos) > wsize[1])
	    wsize_err();
	  if (pos == counter)
	    attron(A_UNDERLINE);
	  if (index[counter] == 1)
	    attron(A_REVERSE);
	  if (sam_strlen(elems[counter]) >= next_hpos)
	    next_hpos = (sam_strlen(elems[counter]) / 8) * 8;
	  mvwprintw(ncwin, vpos, hpos, elems[counter]);
	  vpos++;
	  attroff(A_UNDERLINE);
	  attroff(A_REVERSE);
	}
      counter++;
    }
  return (pos);
}

int	verif_alldel(int *index, int ac)
{
  int	counter;

  counter = 0;
  while (index[counter] == 2)
    counter++;
  if (counter == (ac - 1))
    return (1);
  else
    return (0);
}

int		main(int ac, char **av)
{
  WINDOW	*ncwin;
  int		wsize[2];
  int		*index;
  int		exit_v;
  int		cur_pos;
  int		last_key;

  if (ac < 2)
    arg_err(av);
  index = build_index_table(ac);
  ncwin = initscr();
  noecho();
  keypad(ncwin, true);
  getmaxyx(ncwin, wsize[0], wsize[1]);
  exit_v = 0;
  cur_pos = 1;
  while (!exit_v && !verif_alldel(index, ac))
    {
      clear();
      cur_pos = disp_select(cur_pos, index, av, ncwin, wsize);
      refresh();
      last_key = getch();
      if (last_key == 27)
	{
	  exit_v = 1;
	  clear();
	  endwin();
	}
      else if (last_key == ' ')
	{
	  if (index[cur_pos])
	    index[cur_pos] = 0;
	  else
	    index[cur_pos] = 1;
	  cur_pos++;
	}
      else if ((last_key == KEY_BACKSPACE) || (last_key == KEY_DC))
	{
	  index[cur_pos] = 2;
	  while (index[cur_pos] == 2)
	    cur_pos++;
	}
      else if (last_key == KEY_UP)
	{
	  cur_pos--;
	  while (index[cur_pos] == 2)
	    {
	      cur_pos--;
	      if (cur_pos == 0)
		cur_pos = ac - 1;
	    }
	}
      else if (last_key == KEY_DOWN)
	{
	  cur_pos++;
	  while (index[cur_pos] == 2)
	    {
	      cur_pos++;
	      if (cur_pos == ac)
		cur_pos = ac;
	    }
	}
      else if (last_key == '\n')
	{
	  print_select_exit(av, index, ac);
	  exit_v = 1;
	}
      if (cur_pos == 0)
	{
	  cur_pos = ac - 1;
	  while (index[cur_pos] == 2)
	    cur_pos--;
	}
      if (cur_pos == ac)
	{
	  cur_pos = 1;
	  while (index[cur_pos] == 2)
	    cur_pos++;
	}
    }
  return (0);
}
