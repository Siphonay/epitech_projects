/*
** analyze_format.c for my printf in /home/sam
**
** Made by Alexis Viguié
** Login   <sam@epitech.net>
**
** Started on  Mon Nov 16 11:30:39 2015 Alexis Viguié
** Last update Mon Nov 16 11:55:47 2015 Alexis Viguié
*/

#include <stdarg.h>

int	is_format_invalid(char ftype)
{
  int	invalid;
  char	*valid_ftypes;
  int	counter;

  valid_ftypes = "sSdixXobc%\0";
  invalid = 1;
  counter = 0;
  while (valid_ftypes[counter] != '\0')
    {
      if (valid_ftypes[counter] == ftype)
	invalid = 0;
      counter++;
    }
  return (invalid);
}

int	analyze_format(char *format)
{
  int	counter;

  counter = 0;
  while (format[counter] != '\0')
    {
      if (format[counter] == '%')
	{
	  counter++;
	  if (is_format_invalid(format[counter]))
	    return (1);
	}
      else
	counter++;
    }
  return (0);
}
